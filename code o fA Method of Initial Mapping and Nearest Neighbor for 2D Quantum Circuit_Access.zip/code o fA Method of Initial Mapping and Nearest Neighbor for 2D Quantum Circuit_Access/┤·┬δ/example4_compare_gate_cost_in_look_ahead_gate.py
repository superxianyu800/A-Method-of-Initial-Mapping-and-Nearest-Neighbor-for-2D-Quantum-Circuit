import numpy as np
import copy
import random
from new_experment import weight_main
# 网格转成字典
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/4mod5-v1_22.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/mod5mils_65.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/alu-v0_27.txt'
step = [[-1, 0],
        [1, 0],
        [0, -1],
        [0, 1]]

# 将量子位初始映射在规则网格中
init_grid = weight_main.result
filepath = weight_main.filepath
# init_grid = [[ 2 , 4 , 5,  6  ,7],
#  [ 1 , 0 , 8 , 9, 10],
#  [11,  3 ,12 ,13, 14],
#  [15 ,16, 17, 18 ,19]]
#init_grid = [[2, 4, 5, 6, 7], [3, 0, 8, 9, 10], [11, 1, 12, 13, 14], [15, 16, 17, 18, 19]]
# 初始量子位对应坐标的字典形式
# init_dict = {
#     0: (1, 1),
#     1: (0, 1),
#     2: (0, 0),
#     3: (0, 2),
#     4: (1, 2),
#     5: (2, 2),
#     6: (2, 1),
#     7: (1, 0),
#     8: (2, 0)
# }

#
#gate = [[0, 1], [1, 0], [2, 0], [0, 2], [2, 0], [0, 4], [4, 0], [0, 5], [1, 2], [2, 1],
               #[1, 2], [3, 1], [1, 3], [3, 1], [1, 3], [6, 1], [3, 4], [4, 3], [3, 5], [5, 3],
            # [3, 5], [6, 3], [3, 6], [6, 3], [4, 5], [5, 4], [4, 5], [5, 4], [5, 6], [6, 5]]

#gate =  [[2,6],[0,5],[6,5],[1,4],[3,4],[2,3],[0,4]]
def get_gate(filepath):
    data_list = []
    f = open(filepath, 'r')
    data = f.readlines()
    for line in data:
        xy = line.split()
        data_list.append([eval(xy[0]), eval(xy[1])])
    return data_list

gate = get_gate(filepath)

gate_count =len(gate)
# 判断曼哈顿距离（欧式距离）是否等于1，等于1则近邻，无序近邻化操作
def whether_nn(start_point_x, start_point_y, end_point_x, end_point_y):
    manhattan_distance = abs(start_point_x - end_point_x) + abs(start_point_y - end_point_y)
    if manhattan_distance == 1:
        return True
    else:
        return False



# 判断是否在网格中
def is_in_grid(x, y, grids):
    if x < 0 or y < 0 or x >= len(grids[0]) or y >= len(grids):
        return False
    else:
        return True

#寻找当前坐标对应量子位的相邻量子位
#返回一个相邻量子位的列表
def find_neighbour_point(start_point_x, start_point_y, grid, dict):
    list = []
    for i in range(len(step)):
        x = start_point_x + step[i][0]
        y = start_point_y + step[i][1]
        if is_in_grid(x, y, grid):
            list.append((x, y))
    neighbour_point_list = []
    for i in range(len(list)):
        for key in dict.keys():
            if list[i][0] == dict.get(key)[0] and list[i][1] == dict.get(key)[1]:
                neighbour_point_list.append(key)
    return neighbour_point_list

#将量子位在网格中的相邻的点转化成对应字典
def neighbour_qubit_transform_to_dict(grid,dict):
    new_dict = {}
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            list = find_neighbour_point(i, j, grid,dict)
            d = { grid[i][j] : list}
            new_dict.update(d)

    return new_dict


#查找控制位和目标位生成的局部近邻的图
#将局部近邻图上除目标位上的点都设置为相遇点
def local_grid_meet_point_list(con_point,tar_point,dict):
    local_grid_list =[]
    con_point_x = dict.get(con_point)[0]
    con_point_y = dict.get(con_point)[1]

    tar_point_x = dict.get(tar_point)[0]
    tar_point_y = dict.get(tar_point)[1]

    i = min(con_point_y,tar_point_y)
    j = max(con_point_y,tar_point_y)

    m = min(con_point_x,tar_point_x)
    n = max(con_point_x,tar_point_x)

    for k in range(m,n+1):
        for l in range(i,j+1):
            for key in dict.keys():
                if k == dict.get(key)[0] and l == dict.get(key)[1]:
                    local_grid_list.append(key)
    local_grid_list.remove(tar_point)
    return local_grid_list



# 查找所有路径
def find_all_path(graph, start, end, path=[]):
    path = path + [start]
    if start == end:
        return [path]

    paths = []  # 存储所有路径
    for node in graph[start]:
        if node not in path:
            newpaths = find_all_path(graph, node, end, path)
            for newpath in newpaths:
                paths.append(newpath)
    return paths


# 查找最短路径
def find_shortest_path(graph, start, end, path=[]):
    path = path + [start]
    if start == end:
        return path

    shortestPath = []
    for node in graph[start]:
        if node not in path:
            newpath = find_shortest_path(graph, node, end, path)
            if newpath:
                if not shortestPath or len(newpath) < len(shortestPath):
                    shortestPath = newpath
    return shortestPath


# 获取所有最短路径
def get_all_shortest_path(allpath, shortest_path):
    all_shortest_path = []
    for path in allpath:
        if len(path) == len(shortest_path):
            all_shortest_path.append(path)
    return all_shortest_path




# 交换grid上两个量子位
def swap(a, b, grid, dict):
    a_x = dict.get(a)[0]
    a_y = dict.get(a)[1]

    b_x = dict.get(b)[0]
    b_y = dict.get(b)[1]

    temp = grid[a_x][a_y]
    grid[a_x][a_y] = grid[b_x][b_y]
    grid[b_x][b_y] = temp


# 跟新量子位对应坐标的字典
# 更新插入量子位后的电路
# 按照每一条路径插入电路
# 插入swap后，需要改变init_grids,init_dict
# 参数是一个列表
# 交换更新网格上的点
# 返回一个更新过量子位的新网格


def from_tar_insert_swap_and_update_grid(list, grid, dict):
    for i in range(len(list) - 2):
        swap(list[i], list[i + 1], grid, dict)
    return grid


# 交换更新网格上的点同时更新对应的坐标字典
# 或者返回到原来grid时同时更新对应的坐标字典
# 返回一个更新过量子位坐标的新字典
def grid_transform_dict(grid):
    dict = {}
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            d = {grid[i][j]: (i, j)}
            dict.update(d)
    return dict


#该函数实现是将控制位移动到相遇点
def from_con_insert_swap_to_meet_point_and_update_grid(list,grid,dict):
    for i in range(len(list)-1):
        swap(list[i], list[i + 1], grid, dict)
    return grid


#曼哈顿估算函数
def manhattan_cost(a,b,dict):
    con_x = dict.get(a)[0]
    con_y = dict.get(a)[1]
    tar_x = dict.get(b)[0]
    tar_y = dict.get(b)[1]
    return abs( con_x - tar_x) + abs(con_y - tar_y)

#找出在局部grid中目标位近邻的点
def find_local_grid_tar_point_neighbour_point(list,tar_point,dict):
    new_list = []
    for point in list:
        if manhattan_cost(point,tar_point,dict)  == 1:
            new_list.append(point)
    return new_list



#计算该插入方式对后续量子门代价
def look_head_swap_cost(gate,dict,w,a=0):
    for i in range(w):
        a = a + manhattan_cost(gate[i][0],gate[i][1],dict)
    return a

#返回一个后续各个量子门代价的列表
def look_ahead_gate_cost_list(gate,dict,w):
    list = []
    for i in range(w):
        list.append(manhattan_cost(gate[i][0],gate[i][1],dict))
    return list

def is_not_all_is_min(list):
    a = set(list)
    if  len(a) == 1:
        return 1

def get_same_look_ahead_gate_path_index(path_cost,a,b):
    cost_list = [i[a] for i in path_cost]
    list1 = []
    for j in range(len(path_cost)):
        if path_cost[j][a] == min(cost_list):
            list1.append([path_cost.index(path_cost[j]),path_cost[j][b]])
    list2=[]
    for n in range(len(list1[0][1])):
        list3 =[m[1] for m in list1]
        list2.append(list(np.array(list3).T[n]))
    for x in range(len(list2)):
        #如果第一列的数都是1，接着找
        if is_not_all_is_min(list2[x]) == 1:
            if x < len(list2)-1:
                continue
            else:
                z = [y[0] for y in list1]
                return random.choice(z)
        if  is_not_all_is_min(list2[x]) != 1:
            new_index = list2[x].index(min(list2[x]))
            return new_index


#记录swap门总数
count_swap = 0
# 记录门位置的索引
g_id = 0
# 前瞻大小
w = 4
#存放grid的栈
grid_stack = [init_grid]
for i in range(g_id, len(gate)):
    new_list = []
    con_point = gate[i][0]
    tar_point = gate[i][1]
    start_point_x = grid_transform_dict(grid_stack[-1]).get(con_point)[0]  # 开始顶点的横坐标 x
    start_point_y = grid_transform_dict(grid_stack[-1]).get(con_point)[1]  # 开始顶点的横坐标 y

    end_point_x = grid_transform_dict(grid_stack[-1]).get(tar_point)[0]
    end_point_y = grid_transform_dict(grid_stack[-1]).get(tar_point)[1]

    is_or_nn = whether_nn(start_point_x=start_point_x, start_point_y=start_point_y,
                          end_point_x=end_point_x, end_point_y=end_point_y)

    if is_or_nn:
        print("当前第{0}个门,控制位：{1}，目标位：{2}是近邻的".format((g_id + 1),con_point,tar_point))
        g_id = g_id + 1
        continue
    else:
        print("当前第{0}个门,控制位：{1}，目标位：{2}需要进行近邻化操作".format((g_id + 1),con_point,tar_point))
        #当前门的位置
        #g_id = g_id + 1
        # 获取当前门在网格上控制位到目标位上的最短路径
        new_dict = neighbour_qubit_transform_to_dict(grid_stack[-1],grid_transform_dict(grid_stack[-1]))
        new_path = local_grid_meet_point_list(con_point,tar_point,grid_transform_dict(grid_stack[-1]))
        local_neighbour_point = find_local_grid_tar_point_neighbour_point(new_path,tar_point,grid_transform_dict(grid_stack[-1]))
        # 将最短路径上的第一个点到倒数第二个点作为相遇点路径
        print('当前控制位到目标位的最短路径{0}'.format(new_path))
        #存放相遇点，代价，路径长度-1（代表插入的swap门数）的列表
        #相遇点列表
        now_meet_point = []
        meet_point_cost_swap_count = []
        #遍历所有的相遇点
        for i in range(len(new_path)):
            #如果相遇点是在控制位
            #控制位不懂，将目标位移动到控制位附近
            #记录当前相遇点
            now_meet_point = new_path[i]
            #print("当前相遇点是{0}".format(now_meet_point))
            if now_meet_point == con_point:
                print("当前相遇点是{0}".format(now_meet_point))
                # 直接找出控制位到目标位上所有的最短路径
                temp_tar_all_shortest_path = get_all_shortest_path(find_all_path(new_dict, tar_point, now_meet_point),
                                                               find_shortest_path(new_dict, tar_point,now_meet_point))
                print('该相遇点上的所有最短路径{0}'.format(temp_tar_all_shortest_path))
                #break
                #设置字典，存储所有目标位到相遇点（此时的相遇点是控制位）路径和代价
                all_shortest_path_cost = []
                for i in range(len(temp_tar_all_shortest_path)):
                    #print(temp_all_shortest_path[i])
                    # 按照路径插入交换门，返回一个新的grid
                    a = copy.deepcopy(grid_stack[-1])
                    now_path_grid = from_tar_insert_swap_and_update_grid(temp_tar_all_shortest_path[i], a, grid_transform_dict(a))
                    #print(now_path_grid)
                    #print("当前路径{0}插入swap对应的网格：\n{1}".format(temp_all_shortest_path[i],now_path_grid))
                    #新的grid生成新的坐标dict
                    #now_path_dict = grid_transform_dict(now_path_grid)
                    #在新的grid和dict上计算前瞻代价
                    #且从当前非近邻的门开始算
                    #判断前瞻的门数够不够
                    #当剩余的门数不够设置的前瞻数时，此时的前瞻数w=总门数-当前第几个门
                    if gate_count - (g_id+1) >= w :
                        #cost = look_head_swap_cost(gate[g_id:],  grid_transform_dict(now_path_grid), w)
                        gate_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(now_path_grid), w)
                    else:
                        #cost = look_head_swap_cost(gate[g_id:], grid_transform_dict(now_path_grid),gate_count - (g_id+1)+1)
                        gate_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(now_path_grid), gate_count - (g_id+1)+1)
                    #print(cost)
                    #因为列表不可以作为字典的键加入字典,所以需要将子列表拼间成在母列表里的元素
                    #all_shortest_path_cost.append([temp_tar_all_shortest_path[i], now_path_grid,cost,gate_cost_list])
                    all_shortest_path_cost.append([temp_tar_all_shortest_path[i], now_path_grid,sum(gate_cost_list), gate_cost_list])
                    #打印所有最短路径下的路径和代价字典，dict = {'路径'：代价}
                #print(all_shortest_path_cost)
                #break
                #再将网格返回到原网格，以便下一条路径进行插入，计算
                #插入后，计算出当前路径对应的cost
                #返回到上一个grid和dict的
                #因为将grid放在栈里面记录的，所以不需要返回原来的grid,只需要查找即可。
                #以便计算下一个路径的代价
                #meetpoint_cost_swapcount.append([相遇点，0,[该相遇点对应下的路径]（目标位到相遇点附近的最佳路径），该相遇点对应的代价，插入swap后的新的grid])
                #0代表的是从控制位往相遇点插入swap，如果为0代表没有这条路径。
                list1_index = get_same_look_ahead_gate_path_index(all_shortest_path_cost,2,3)
                meet_point_cost_swap_count.append([now_meet_point,0,all_shortest_path_cost[list1_index][0],
                                                   all_shortest_path_cost[list1_index][2], all_shortest_path_cost[list1_index][3],all_shortest_path_cost[list1_index][1]])
                # list1 = compare_look_ahead_gate(all_shortest_path_cost)
                # list1[1] = 0
                # meet_point_cost_swap_count.append(compare_look_ahead_gate(all_shortest_path_cost))
                print('该相遇点下最佳插入路径：',all_shortest_path_cost[list1_index][0])
            #当相遇点与目标位近邻时
            #此时将控制位移动到相遇点
            #目标位不动
            elif  now_meet_point in  local_neighbour_point:
                print("当前相遇点是{0}".format(now_meet_point))

                temp_con_all_shortest_path = get_all_shortest_path(find_all_path(new_dict, con_point, now_meet_point),
                                                               find_shortest_path(new_dict, con_point, now_meet_point))
                print('控制位到该相遇点上的所有最短路径{0}'.format(temp_con_all_shortest_path))
                # break
                # 设置字典，存储所有目标位到相遇点（此时的相遇点是控制位）路径和代价
                con_to_meet_point_all_shortest_path_cost = []
                for i in range(len(temp_con_all_shortest_path)):
                    # print(temp_all_shortest_path[i])
                    # 按照路径插入交换门，返回一个新的grid
                    e = copy.deepcopy(grid_stack[-1])
                    con_to_meet_point_path_grid =  from_con_insert_swap_to_meet_point_and_update_grid(temp_con_all_shortest_path[i], e,
                                                                         grid_transform_dict(e))
                    # print("当前路径{0}插入swap对应的网格：\n{1}".format(temp_all_shortest_path[i],now_path_grid))
                    # 新的grid生成新的坐标dict
                    # now_path_dict = grid_transform_dict(now_path_grid)
                    # 在新的grid和dict上计算前瞻代价
                    # 且从当前非近邻的门开始算
                    # 判断前瞻的门数够不够
                    # 当剩余的门数不够设置的前瞻数时，此时的前瞻数w=总门数-当前第几个门
                    if gate_count - (g_id + 1) >= w:
                        # cost = look_head_swap_cost(gate[g_id:],  grid_transform_dict(now_path_grid), w)
                        gate_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(con_to_meet_point_path_grid), w)
                    else:
                        # cost = look_head_swap_cost(gate[g_id:], grid_transform_dict(now_path_grid),gate_count - (g_id+1)+1)
                        gate_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(con_to_meet_point_path_grid),
                                                                   gate_count - (g_id + 1) + 1)
                    # print(cost)
                    # 因为列表不可以作为字典的键加入字典,所以需要将子列表拼间成在母列表里的元素
                    con_to_meet_point_all_shortest_path_cost.append([temp_con_all_shortest_path[i], con_to_meet_point_path_grid, sum(gate_cost_list),gate_cost_list])
                #print(con_to_meet_point_all_shortest_path_cost)
                # break
                # 再将网格返回到原网格，以便下一条路径进行插入，计算
                # 插入后，计算出当前路径对应的cost
                # 返回到上一个grid和dict的
                # 因为将grid放在栈里面记录的，所以不需要返回原来的grid,只需要查找即可。
                # 以便计算下一个路径的代价
                # meetpoint_cost_swapcount.append([相遇点，0,[该相遇点对应下的代价]，该相遇点对应的代价])
                # 0代表的是从控制位往相遇点插入swap，如果为0代表没有这条路径。
                list4_index = get_same_look_ahead_gate_path_index(con_to_meet_point_all_shortest_path_cost,2,3)
                meet_point_cost_swap_count.append([now_meet_point,  con_to_meet_point_all_shortest_path_cost[list4_index][0], 0,
                                               con_to_meet_point_all_shortest_path_cost[list4_index][2],con_to_meet_point_all_shortest_path_cost[list4_index][3],con_to_meet_point_all_shortest_path_cost[list4_index][1]])
                #print(meet_point_cost_swap_count)
                print('该相遇点下最佳插入路径：', con_to_meet_point_all_shortest_path_cost[list4_index][0])
            # 当相遇点不是控制位的时候
            # 需要将控制位移动到相遇点
            # 目标位移动到相遇点附近的位置
            elif  now_meet_point !=  con_point and  now_meet_point not in  local_neighbour_point:
                print("当前相遇点是{0}".format(now_meet_point))
                #存放控制位到相遇点代价最小路径和目标位到相遇点近邻位置的代价最小路径列表
                con_and_tar_shortest_cost_path = []
                #将控制位移动到相遇点
                #获取所有的控制位到相遇点的所有最短路径
                con_to_meet_point_all_shortest_path = get_all_shortest_path(find_all_path(new_dict,con_point, now_meet_point), find_shortest_path(new_dict, con_point, now_meet_point))
                print('控制位到该相遇点上的所有最短路径{0}'.format(con_to_meet_point_all_shortest_path))
                #设置字典，存储所有的控制位到相遇点的所有最短路径和对应代价
                all_con_to_meet_point_all_shortest_path_cost = []
                #遍历每一条从控制位到相遇点的所有最短路径
                for i in range(len(con_to_meet_point_all_shortest_path)):
                    # print(temp_all_shortest_path[i])
                    # 按照路径插入交换门，返回一个新的grid
                    #从控制位上需要插入到相遇点
                    #从目标位上只需要插入到相遇点附近的位置
                    b = copy.deepcopy(grid_stack[-1])
                    from_con_to_meet_point_path_grid = from_con_insert_swap_to_meet_point_and_update_grid(con_to_meet_point_all_shortest_path[i],b,grid_transform_dict(b))
                    # 新的grid生成新的坐标dict
                    #from_con_to_meet_point_path_dict = grid_transform_dict(from_con_to_meet_point_path_grid)
                    # 在新的grid和dict上计算前瞻代价
                    #计算从当前门开始前瞻代价
                    if gate_count - (g_id + 1) >= w:
                        from_con_to_meet_point_path_cost_list = look_ahead_gate_cost_list(gate[g_id:],grid_transform_dict(from_con_to_meet_point_path_grid), w)
                    else:
                        from_con_to_meet_point_path_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(from_con_to_meet_point_path_grid), gate_count - (g_id + 1)+1)
                    # print(cost)
                    all_con_to_meet_point_all_shortest_path_cost.append([con_to_meet_point_all_shortest_path[i],sum(from_con_to_meet_point_path_cost_list),from_con_to_meet_point_path_cost_list])
                    #print(all_con_to_meet_point_all_shortest_path_cost)
                    # 打印所有最短路径下的路径和代价字典，dict = {'路径'：代价}
                #找出控制位到相遇点下代价最小的路径，只记录路径
                list2_index = get_same_look_ahead_gate_path_index(all_con_to_meet_point_all_shortest_path_cost,1,2)
                con_and_tar_shortest_cost_path.append(all_con_to_meet_point_all_shortest_path_cost[list2_index][0])
                print('找出控制位到相遇点下代价最小的路径，只记录路径',con_and_tar_shortest_cost_path)
                #将目标位移动到相遇点附近的位置
                # 获取所有的控制位到相遇点的所有最短路径
                tar_to_meet_point_all_shortest_path = get_all_shortest_path(find_all_path(new_dict, tar_point, now_meet_point),find_shortest_path(new_dict, tar_point,now_meet_point))

                print('目标位到该相遇点上的所有最短路径{0}'.format(tar_to_meet_point_all_shortest_path))
                # 设置字典，存储所有的控制位到相遇点的所有最短路径和对应代价
                all_tar_to_meet_point_all_shortest_path_cost = []
                # 遍历每一条从控制位到相遇点的所有最短路径
                for i in range(len(tar_to_meet_point_all_shortest_path)):
                    # print(temp_all_shortest_path[i])
                    # 按照路径插入交换门，返回一个新的grid
                    # 从控制位上需要插入到相遇点
                    # 从目标位上只需要插入到相遇点附近的位置
                    c=copy.deepcopy(grid_stack[-1])
                    from_tar_to_meet_point_path_grid = from_tar_insert_swap_and_update_grid(tar_to_meet_point_all_shortest_path[i], c, grid_transform_dict(c))
                    # 新的grid生成新的坐标dict
                    #from_tar_to_meet_point_path_dict = grid_transform_dict(from_tar_to_meet_point_path_grid)
                    # 在新的grid和dict上计算前瞻代价
                    #计算从当前门开始的前瞻代价
                    if gate_count - (g_id + 1) >= w:
                        from_tar_to_meet_point_path_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(from_tar_to_meet_point_path_grid), w)
                    else:
                        from_tar_to_meet_point_path_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(from_tar_to_meet_point_path_grid), gate_count - (g_id + 1)+1)
                    # print(cost)
                    # 因为列表不可以作为字典的键加入字典,所以需要将子列表拼间成在母列表里的元素
                    all_tar_to_meet_point_all_shortest_path_cost.append([tar_to_meet_point_all_shortest_path[i],sum(from_tar_to_meet_point_path_cost_list),from_tar_to_meet_point_path_cost_list])
                    # 打印所有最短路径下的路径和代价字典，dict = {'路径'：代价}
                    #print(all_tar_to_meet_point_all_shortest_path_cost)
                # 找出目标位到相遇点近邻位置下代价最小的路径，只记录路径
                list3_index = get_same_look_ahead_gate_path_index(all_tar_to_meet_point_all_shortest_path_cost,1,2)
                con_and_tar_shortest_cost_path.append(all_tar_to_meet_point_all_shortest_path_cost[list3_index][0])
                print('目标位到控制位附近点的最小路径，只记录路径',con_and_tar_shortest_cost_path)
                #按照上面两个路径插入swap门，在计算代价
                #并且将从控制位到相遇点和目标位到相遇点附近位置的路径，路径代价，当前相遇点添加到meetpoint_cost_swapcount.append([相遇点，0,[该相遇点对应下的代价]，该相遇点对应的代价])
                #[[控制位到相遇点的最小路径]，[目标位到相遇点附近位置的最小路径]]
                d = copy.deepcopy(grid_stack[-1])
                temp_from_con_to_meet_point_path_grid = from_con_insert_swap_to_meet_point_and_update_grid(con_and_tar_shortest_cost_path[0], d, grid_transform_dict(d))
                con_and_tar_to_meet_point_path_grid = from_tar_insert_swap_and_update_grid(con_and_tar_shortest_cost_path[1],  temp_from_con_to_meet_point_path_grid, grid_transform_dict(temp_from_con_to_meet_point_path_grid))
                if gate_count - (g_id + 1) >= w:
                    con_and_tar_sum_to_meet_point_path_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(con_and_tar_to_meet_point_path_grid), w)
                else:
                    con_and_tar_sum_to_meet_point_path_cost_list = look_ahead_gate_cost_list(gate[g_id:], grid_transform_dict(con_and_tar_to_meet_point_path_grid), gate_count - (g_id + 1)+1)
                #print(con_and_tar_sum_to_meet_point_path_cost)
                meet_point_cost_swap_count.append([now_meet_point, con_and_tar_shortest_cost_path[0], con_and_tar_shortest_cost_path[1],
                                                   sum(con_and_tar_sum_to_meet_point_path_cost_list),con_and_tar_sum_to_meet_point_path_cost_list,con_and_tar_to_meet_point_path_grid])
        #print('各个相遇点的代价列表:',meet_point_cost_swap_count)
        #对比所有相遇点下的代价，找出代价最小的那个作为最后插入swap的那个路径
        #各相遇点代价相同情况
        list5_index = get_same_look_ahead_gate_path_index(meet_point_cost_swap_count,3,4)
        now_insert_path = [meet_point_cost_swap_count[list5_index][1],meet_point_cost_swap_count[list5_index][2]]
        now_insert_path_grid = meet_point_cost_swap_count[list5_index][5]
        print('实现该门近邻的最佳插入路径',now_insert_path )
        if now_insert_path[0] != 0 and now_insert_path[1] != 0:
            count_swap = count_swap + len(now_insert_path[0]) - 1 + len(now_insert_path[1]) - 2
        if now_insert_path[0] == 0:
            count_swap = count_swap + len(now_insert_path[1]) - 2
        if now_insert_path[1] == 0:
            count_swap = count_swap + len(now_insert_path[0]) - 1
        print('近邻当前门需要插入的swap个数',count_swap)
        print( )
        grid_stack.append(now_insert_path_grid)
        print('近邻当前第{0}个门后的映射布局\n{1}'.format(g_id+1,grid_stack[-1]))
        g_id = g_id + 1
        #pass
print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
print('==================完====================')
print('==================成====================')
print('==================后====================')
print( )
print('完成近邻后总的插入门数',count_swap)