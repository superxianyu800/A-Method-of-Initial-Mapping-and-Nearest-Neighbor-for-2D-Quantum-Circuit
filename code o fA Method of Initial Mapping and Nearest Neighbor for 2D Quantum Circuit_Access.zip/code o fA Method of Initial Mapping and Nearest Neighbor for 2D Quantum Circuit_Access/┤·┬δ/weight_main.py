
import numpy as np
import math
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/4mod5-v1_22.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/mod5mils_65.txt'
filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/alu-v0_27.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/4mod5-v1_22.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/4gt13_92.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/ising_model_10.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/ising_model_13.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/ising_model_16.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/qft_10.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/qft_13.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/qft_16.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/qft_20.txt'failed
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/rd84_142.txt'failed
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/adr4_197.txt'failed
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/radd_250.txt'failed
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/z4_268.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/sym6_145.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/misex1_241.txt'failed
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/rd73_252.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/cycle10_2_110.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/square_root_7.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/sqn_258.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/rd84_253.txt'(2,2)
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/co14_215.txt'failed
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/sym9_193.txt'
#filepath = 'C:/Users/14148/Desktop/test_example/test1_benchmark/9symml_195.txt'
class qc_init():
    def __init__(self):
        '''包含一个二维numpy数组'''
        #量子门个数
        self.gate_count=0
        #量子门控制位目标位存放的二维数组
        self.gate=None
        #量子位个数
        self.qc_num = 0
        #self.qc_amatrix = None
        #每量子位上的量子门的索引
        self.qc_index = []
        #根据权重降序排列的量子位序列
        self.target_index = []
        #网格的高
        self.grid_H = 0
        #网格的宽
        self.grid_W = 0
        #网格的初始映射
        self.grid_placement = None
        # self.nodes是节点数
        self.nodes = []
        # self.sides是门，也可以看做是边
        self.sides = []
        # self.sequense是字典，key是点，value是与key相连接的点
        self.sequense = {}
        # self.side是临时表
        self.side = []
        #存放初始映射量子位坐标的字典
        self.dict = {}
        #存放未放置量子位的坐标
        self.null_qu_bit_list = []


    def ini_circuit(self):
        if(self.gate_count):
            data_list = []
            f = open(filepath, 'r')
            data = f.readlines()
            for line in data:
                xy = line.split()
                data_list.append([eval(xy[0]), eval(xy[1])])
                self.gate = np.array(data_list)
            print("----------将每个门初始化为量子门个数*2的二维矩阵----------")
            print(self.gate)
        else:
            print("量子门数为空 请重新导入量子线路！")


    #每个量子位上的量子门的索引
    def get_index(self):
        for i in range(self.qc_num):  # data   [ 30 *2]
            index_list = []
            for leng in range(len(self.gate)):
                if i in self.gate[leng]:
                    index_list.append(leng + 1)  # 求的是某个量子位的有0/1/...的下标
            self.qc_index.append(index_list)
        print("----------每个量子位上的量子门的索引----------")
        print(self.qc_index)


    #根据量子门位置权重降序排列的量子位序列
    def weightsort(self):
        index_ = []
        for i in self.qc_index:
            i = np.array(i)
            a = (self.gate_count - i + 1) / self.gate_count
            index_.append(np.sum(a))
        while True:
            max_i = index_.index(max(index_))
            # print(max_i)
            index_[max_i] = 0
            self.target_index.append(max_i)
            if sum(index_) == 0:
                break
        print("----------根据量子门位置权重降序排列的量子位序列----------")
        print(self.target_index)


    #量子门个数
    def qc_file(self):
        #self.gate_count = 30
        with open(filepath, "rb") as f:
            for i in f:
                self.gate_count += 1
            print("----------量子门个数----------")
            print(self.gate_count)


    #量子位数
    def find_qcnum(self):
        for qcnum_sep in np.nditer(self.gate):
            # print(qcnum_sep)
            if qcnum_sep > self.qc_num:  # 如果
                self.qc_num = qcnum_sep
        # 为什么self中的变量不可以进行累加
        temp_qc_num = self.qc_num + 1
        self.qc_num = temp_qc_num
        print("----------量子位个数----------")
        print(self.qc_num)

    #将量子门转换字典
    def get_dict(self):
        self.sides=self.gate
        self.nodes = [i for i in range(self.qc_num)]
        for node in self.nodes :
            for side in self.sides:
                u,v = side
                #指定点与另一个点在同一个边中，则说明这个点与指定点是相连接的点，则需要将这个点放到self.side中
                if node  == u:
                    self.side.append(v)
                elif node == v:
                    self.side.append(u)
            self.sequense[node] = self.side
            self.side=[]
        print("----------将量子门转换为字典----------")
        print(self.sequense)
        #return self.sequense


    def qc_placement(self):
        # 生成二维网格
        # self.grid_H = math.ceil(self.qc_num ** 0.5)
        # self.grid_W = math.ceil(self.qc_num / self.grid_H)
        #网格高度
        self.grid_W =  5
        #网格宽度
        self.grid_H = 4
        # 初始化量子比特放置位置表,全部用-1初始化所有元素
        self.grid_placement = np.full([self.grid_H, self.grid_W], -1)
        #初始化二维网格
        print("----------初始化二维网格----------")
        print(self.grid_placement)
        print("----------输出二维网格的初始映射----------")
        step = [[-1, 0],
               [1, 0],
               [0, -1],
               [0, 1]]
        flag = np.zeros((self.grid_H, self.grid_W))
        gate = self.sequense

        stack = []
        #dict = {}
        queue = []
        s_index = 0
        stack.append(self.target_index[0])
        queue.append(self.target_index[0])
        #网格的中心位置，(ix，iy)
        ix = 2
        iy = 1
        self.grid_placement[ix, iy] = self.target_index[0]
        #flag设置为1代表这个点已经放置
        flag[ix, iy] = 1
        self.dict[stack[s_index]] = (ix, iy)
        while len(queue) < self.qc_num:
            temp = []
            gate_index = 0
            for w in gate[stack[s_index]]:
                if w not in queue:
                    q = stack[s_index]
                    # w是在q里面找到的，寻找q对应字典里面的坐标
                    for j in range(len(step)):
                        if self.dict.get(q)[0] + step[j][0] == len(self.grid_placement):
                            continue
                        if self.dict.get(q)[0] + step[j][0] == -1:
                            continue
                        if self.dict.get(q)[1] + step[j][1] == len(self.grid_placement):
                            continue
                        if self.dict.get(q)[1] + step[j][1] == -1:
                            continue
                        if flag[self.dict.get(q)[0] + step[j][0], self.dict.get(q)[1] + step[j][1]] == 1:
                            continue
                        ix = self.dict.get(q)[0] + step[j][0]
                        iy = self.dict.get(q)[1] + step[j][1]
                        self.grid_placement[ix, iy] = w
                        stack.append(w)
                        queue.append(w)
                        s_index = s_index + 1
                        self.dict.setdefault(w, (ix, iy))
                        flag[ix, iy] = 1
                        break
                    break
                if w in queue:
                    temp.append(w)
                    gate_index = gate_index + 1
                    if gate_index == len(gate[stack[s_index]]):
                        d = [False for a in temp if a not in queue]
                        if d == []:
                            stack.pop()
                            s_index = s_index - 1

        print(self.grid_placement)
        print("----------输出二维网格的初始映射量子位对应坐标----------")
        print(self.dict)

    def init_placement(self):
        for i in range( self.grid_H):
            for j in range( self.grid_W):
                if self.grid_placement[i][j] == -1:
                    self.null_qu_bit_list.append((i, j))
                else:
                    self.dict[self.grid_placement[i][j]] = (i, j)
        print("----------已放入量子位对应坐标的字典----------")
        print(self.dict)
        print("----------未放置量子位的坐标的列表----------")
        print(self.null_qu_bit_list)

    def init_dict_and_grid(self):
        index = 0
        for i in range(self.qc_num, self.grid_W  * self.grid_H):
            self.dict[i] = self.null_qu_bit_list[index]
            index = index + 1
        print("----------将未放入量子位的坐标放入已放入量子位的字典中----------")
        print(self.dict)
        print("----------初始映射后的网格----------")
        for k in self.dict.keys():
            i, j = self.dict[k]
            self.grid_placement[i][j] = k
        print(self.grid_placement)
        return self.grid_placement





my_init=qc_init()
#输出多少个量子门
my_init.qc_file()
#读入文件，输出矩阵 大小为:2*self.gate_count
my_init.ini_circuit()
#输出量子位数
my_init.find_qcnum()
#输出每个量子位上的门的索引顺序（从1开始）
my_init.get_index()
#输出量子位权重对应的量子位（降序）
my_init.weightsort()
#将量子门转换为字典形式
my_init.get_dict()
#深度搜索量子门近邻放置量子位
my_init.qc_placement()
#设置未放置的量子位
my_init.init_placement()
#更新量子位对应坐标和网格
result=my_init.init_dict_and_grid()